package array;

import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int[] numbers = new int[255];
		
		int[] cisla = {1, 2, 3, 4, 5};
		
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = i;
			System.out.println(numbers[i]);
		}
		
		System.out.println("Ktore cislo z arrayu chces? od 0 po "+cisla.length);
		int vyber = input.nextInt();
		System.out.println("Vybral si : "+cisla[vyber]);
	
	}

}
