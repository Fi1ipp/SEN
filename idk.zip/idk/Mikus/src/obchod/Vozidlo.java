package obchod;

class Vozidlo {
	int cestujuci;
	double objemnadrze;
	double litrenastokm;
	public double dojazd=100*(objemnadrze/litrenastokm);
}
