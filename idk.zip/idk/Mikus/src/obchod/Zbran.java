package obchod;

class Zbran {
	int pocetNabojov;
	int rychlostStrelby;
	double kaliberMM;
	double dlzkaHlavneMM;
	double mnozstvoZlozeG;
	
}
