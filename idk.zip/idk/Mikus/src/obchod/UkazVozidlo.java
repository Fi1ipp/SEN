package obchod;

public class UkazVozidlo {

	public static void main(String[] args) {
		
		Vozidlo minivan=new Vozidlo();
		Vozidlo tank=new Vozidlo();
		
		/*minivan.cestujuci=6;
		minivan.objemnadrze=145;
		minivan.litrenastokm=5;
		
		minivan.dojazd=100*(minivan.objemnadrze/minivan.litrenastokm);
		
		System.out.println("Dojazd minivanu je = "+minivan.dojazd);
		*/
		
		class Zbran extends Vozidlo {
			private String modelName = "armadneVozidlo";
			public static void main(String[] args) {

			    Vozidlo Tank=new Vozidlo();
			   
				
			  }
			}

	}

}
