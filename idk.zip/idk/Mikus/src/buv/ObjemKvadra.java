package buv;

import java.util.Scanner;

public class ObjemKvadra {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		double a,b,c;
		
		System.out.println("Daj a");
		a = input.nextDouble();
		
		System.out.println("Daj b");
		b = input.nextDouble();
		
		System.out.println("Daj c");
		c = input.nextDouble();
		
		double V = a*b*c;
		System.out.println("Objem kvadra = "+V);
		

	}

}
