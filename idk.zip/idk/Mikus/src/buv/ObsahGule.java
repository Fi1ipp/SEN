package buv;

import java.util.Scanner;

public class ObsahGule {

	public static void main(String[] args) {
		
		double d, r;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Zadaj polomer gule :");
		r = input.nextDouble();
		d = r*2;
		
		double O, P, V;
		
		O = Math.PI * d;
		
		P = Obsah(r);

		V = Objem(r);
		
		System.out.println("Obvod : "+O);
		System.out.println("Povrh : "+P);
		System.out.println("Objem : "+V);
	}
	
	public static double Obsah(double r) {
		double d = r*r;
		return Math.PI * (d*d);
	}
	
	public static double Objem(double r) {
		double d = r*r;
		return ((1/6)*Math.PI)*(d*d*d);
	}

}
