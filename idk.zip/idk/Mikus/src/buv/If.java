package buv;

import java.util.Scanner;

public class If {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Zadaj A");
		int a = input.nextInt();
		
		System.out.println("Zadaj B");
		int b = input.nextInt();
		
		System.out.println("Zadaj C");
		int c = input.nextInt();
		
		double Dis = b*b-4*a*c;
		
		double x1, x2;
		
		if (Dis == 0) {
			x1 = -b/(2*a);
			System.out.println("Ma Dvojnasobny koren "+x1);
		}
		
		if (Dis > 0) {
			System.out.println("Diskriminant ma dva korene");
			x1=-b/(2*a)-Math.sqrt(Dis)/(2*a);
			x2=-b/(2*a)+Math.sqrt(Dis)/(2*a);
			System.out.println("Koren 1 : "+x1);
			System.out.println("Koren 2 : "+x2);
		}
		
		if (Dis < 0) {
			System.out.println("Diskriminant nema korene");
		}
		
		

	}

}
