package buv;

import java.util.Scanner;

public class Idk {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		int health = 6;
		
		String zadaj = input.nextLine();
		int textLength = zadaj.length();
		String secret = "";
		
		char hadane;
		
		for (int i = 0; i < textLength; i++) {
			secret=secret+"#";
		}
		for (int i = 0; i < 100; i++) {
			System.out.println("");
		}
		
		if (secret==zadaj) {
			System.out.println("Yay vyhral si slovo bolo : "+zadaj);
		} else if (health==0) {
			System.out.println("Prehral si slovo bolo : "+zadaj);
		} else {
			System.out.println("Hadaj pismenko : ");
			
			
		}
		
		
		

	}

}
