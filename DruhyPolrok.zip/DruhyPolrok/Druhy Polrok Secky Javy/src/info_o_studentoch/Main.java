package info_o_studentoch;

public class Main {

	public static void main(String[] args) {
		Help helper = new Help();
		
		System.out.println("Priemerný vek žiakov je : "+helper.priemernyVek());
		helper.rozdielPercenta();

	}

}
