package main;

import java.util.Random;
import java.util.Scanner;

public class Podmienky {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		double peniaze;
		boolean rusko;
		int weather;
		
		System.out.println("Tvoje financne proztriedky:");
		peniaze = input.nextDouble();
		
		System.out.println("Mas rusko? (true/false)");
		rusko = input.nextBoolean();
		
		System.out.println("Ake je pocasie? (1 = Dazd, 2 = Slnecno, 3 = Veterno, 4 = Tornado, 5 = Koniec Sveta)");
		weather = input.nextInt();
		
		if (peniaze >= 1800 && rusko == true && (weather == 2 || weather == 3)) {
			System.out.println("Idem von.");
		}
		else {
			System.out.println("Nechce sa mi.");
		}
		*/
	
		
		
		
		
		/*
		boolean weather;
		
		System.out.println("Je dnes pekne pocasie? true/false");
		weather =  input.nextBoolean();
		
		if (weather == true) {
			System.out.println("Dnes je pekny den");
		}
		else {
			System.out.println("Dnes je zamracene");
		}
		*/

	}

}
