package funkcie;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Help help = new Help();

		help.vyberSO();
		
		

	}

}
