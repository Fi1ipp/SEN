package priemer;

public class Main {

	public static void main(String[] args) {
		
		Help help = new Help();
		
		System.out.println(help.sucetPocetCisiel());

	}

}
