package main;

import java.util.Scanner;

public class PracaScanner {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		double real1;
		double real2;
		
		System.out.println("Zadaj prve realne cislo :");
		real1=input.nextDouble();
		System.out.println("Zadaj druhe realne cislo :");
		real2=input.nextDouble();
		
		if (real1 > real2) {
			System.out.println("Prve cislo je väcsie ako druhe cislo");
		}
		else if (real1 == real2) {
			System.out.println("Cisla su si rovne");
		}
		else {
			System.out.println("Druhe cislo je väcsie ako prve cislo");
		}
		*/
		
		
		
		

		/*
		int pocet;
		int spolu;
		int inNum;
		
		pocet=0;
		spolu=0;
		
		System.out.println("Daj cislo:");
		inNum = input.nextInt();
		
		while (inNum != 0) {
			pocet++;
			spolu+=inNum;
			System.out.println("Zle cislo skus znova:");
			inNum = input.nextInt();
			if (inNum==0) {
				System.out.println("Dobre");
				System.out.println("Pocet pokusov: "+pocet);
				System.out.println("Cisla ktore si zadal scitane: "+(spolu+1));
			}
		}
		*/
		
		
		
		

		/*
		System.out.println("Napis nieco pekne");
		String inStr = input.nextLine();
		int strLeng = inStr.length();
		System.out.println("Napisal si: "+inStr);
		System.out.println("Dlzka pisma je: "+strLeng);
		*/
	}

}
