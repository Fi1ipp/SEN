package main;

public class Main {

	public static void main(String[] args) {
		
		int num = 5;
		double simplePi = 3.14;
		String text = "Hello";
		boolean bool = true;
		char yes = 'a';
		int x;
		
		x = 6 + 12 + num;
		
		System.out.println(x);

	}

}
