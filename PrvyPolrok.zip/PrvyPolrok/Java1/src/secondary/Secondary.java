package secondary;

public class Secondary {

	public static void main(String[] args) {
		
		int num1 = 54;
		double realnum = 12.6;
		String str = "Hello";
		char z = '&';
		double a;
		double b;
		
		a = num1 + realnum;
		b = realnum - num1;
		
		if (a > b) {
			System.out.println("a > b");
		}
		
		if (a != b) {
			System.out.println("a nieje rovne b");
		}
		/*	if (a == 66.6) {
			System.out.println(str);
		} 
		*/	

		

	}

}
