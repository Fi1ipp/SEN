package main;

public class Uloha1 {

	public static void main(String[] args) {
		
		// Deklaracia Premennych
		
		int pocetBananov = 5;
		char oblubenePismeno = '@';
		double aktualnaTeplota = 25.5;
		boolean mamDostatokPenezi = true;
		String menoHerca = "Maximilián Zábavný";
		
		
		// Kombinovanie premenných
		
		String meno = "John";
		String priezvisko = "Doe";
		
		String celeMeno = meno+" "+priezvisko;
		
		System.out.println("Vitajte "+celeMeno);
		
		
		//Číselné premenné
		
		int cislo1 = 10;
		int cislo2 = 5;
		
		int sucet = cislo1+cislo2;
		
		System.out.println("Súčet čísel: "+sucet);
		
		double podiel = cislo1/cislo2;
		
		System.out.println("Podiel čísel: "+podiel);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
