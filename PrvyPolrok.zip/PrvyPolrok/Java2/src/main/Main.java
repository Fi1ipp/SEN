package main;

public class Main {

	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 8;
		String str = "Pat";
		boolean bool = true;
		
		System.out.println("number1 = "+num1);
		System.out.println("number2 = "+num2);		
		System.out.println("string = "+str);		
		System.out.println("boolean = "+bool);
		
		System.out.println("");
		
		if (num1 != num2) {
			System.out.println("Text");
		}
		
		if (num2 >= num1) {
			System.out.println("Text2");
		}

	}

}
